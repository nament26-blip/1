import React, { useMemo, useState } from "react";
import {
  Search, SlidersHorizontal, Star, PlayCircle, MapPin, Video,
  X, ChevronDown, ShieldCheck
} from "lucide-react";

const FONT_IMPORT = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,500&family=Manrope:wght@400;500;600;700;800&display=swap');
.font-display { font-family: 'Fraunces', serif; }
.font-body { font-family: 'Manrope', sans-serif; }
`;

const REQUESTS = ["Тревога", "Отношения", "Детско-родительские", "Самооценка", "Выгорание", "Горе и потеря"];
const METHODS = ["КПТ", "Психоанализ", "Гештальт-терапия", "Семейная терапия", "EMDR"];
const LANGUAGES = ["Русский", "Английский", "Казахский"];
const GENDERS = ["Любой", "Женщина", "Мужчина"];
const FORMATS = ["Онлайн", "Очно"];

const SPECIALISTS = [
  {
    id: 1, name: "Анна Соколова", gender: "Женщина", price: 40, rating: 4.9, reviews: 132,
    experience: 8, methods: ["КПТ"], requests: ["Тревога", "Отношения"], languages: ["Русский"],
    formats: ["Онлайн", "Очно"], city: "Алматы",
  },
  {
    id: 2, name: "Марат Ким", gender: "Мужчина", price: 55, rating: 4.8, reviews: 98,
    experience: 12, methods: ["Психоанализ"], requests: ["Самооценка", "Выгорание"], languages: ["Русский", "Английский"],
    formats: ["Онлайн"], city: "Онлайн",
  },
  {
    id: 3, name: "Елена Райс", gender: "Женщина", price: 35, rating: 5.0, reviews: 61,
    experience: 6, methods: ["Семейная терапия"], requests: ["Детско-родительские"], languages: ["Русский"],
    formats: ["Онлайн", "Очно"], city: "Астана",
  },
  {
    id: 4, name: "Данияр Утеулиев", gender: "Мужчина", price: 48, rating: 4.7, reviews: 44,
    experience: 5, methods: ["КПТ", "EMDR"], requests: ["Тревога", "Горе и потеря"], languages: ["Русский", "Казахский"],
    formats: ["Онлайн"], city: "Онлайн",
  },
  {
    id: 5, name: "Ольга Птицына", gender: "Женщина", price: 65, rating: 4.9, reviews: 210,
    experience: 15, methods: ["Гештальт-терапия"], requests: ["Отношения", "Самооценка"], languages: ["Русский"],
    formats: ["Очно"], city: "Алматы",
  },
  {
    id: 6, name: "Игорь Ласточкин", gender: "Мужчина", price: 38, rating: 4.6, reviews: 27,
    experience: 4, methods: ["КПТ"], requests: ["Выгорание", "Тревога"], languages: ["Русский", "Английский"],
    formats: ["Онлайн", "Очно"], city: "Онлайн",
  },
];

function FilterGroup({ title, children }) {
  return (
    <div className="border-b border-stone-200 py-5 first:pt-0">
      <p className="mb-3 text-sm font-semibold text-stone-800">{title}</p>
      {children}
    </div>
  );
}

function Checkbox({ label, checked, onChange }) {
  return (
    <label className="flex cursor-pointer items-center gap-2.5 py-1 text-sm text-stone-600">
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        className="h-4 w-4 rounded border-stone-300 text-emerald-700 focus:ring-emerald-600"
      />
      {label}
    </label>
  );
}

function toggle(arr, value) {
  return arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value];
}

export default function CatalogPage() {
  const [query, setQuery] = useState("");
  const [requests, setRequests] = useState([]);
  const [methods, setMethods] = useState([]);
  const [languages, setLanguages] = useState([]);
  const [formats, setFormats] = useState([]);
  const [gender, setGender] = useState("Любой");
  const [maxPrice, setMaxPrice] = useState(70);
  const [sortBy, setSortBy] = useState("rating");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const results = useMemo(() => {
    let list = SPECIALISTS.filter((s) => {
      if (query && !s.name.toLowerCase().includes(query.toLowerCase())) return false;
      if (requests.length && !requests.some((r) => s.requests.includes(r))) return false;
      if (methods.length && !methods.some((m) => s.methods.includes(m))) return false;
      if (languages.length && !languages.some((l) => s.languages.includes(l))) return false;
      if (formats.length && !formats.some((f) => s.formats.includes(f))) return false;
      if (gender !== "Любой" && s.gender !== gender) return false;
      if (s.price > maxPrice) return false;
      return true;
    });
    if (sortBy === "rating") list = [...list].sort((a, b) => b.rating - a.rating);
    if (sortBy === "price_asc") list = [...list].sort((a, b) => a.price - b.price);
    if (sortBy === "price_desc") list = [...list].sort((a, b) => b.price - a.price);
    if (sortBy === "experience") list = [...list].sort((a, b) => b.experience - a.experience);
    return list;
  }, [query, requests, methods, languages, formats, gender, maxPrice, sortBy]);

  const activeCount =
    requests.length + methods.length + languages.length + formats.length + (gender !== "Любой" ? 1 : 0);

  const FiltersPanel = (
    <div className="font-body">
      <FilterGroup title="Запрос">
        <div className="flex flex-col">
          {REQUESTS.map((r) => (
            <Checkbox key={r} label={r} checked={requests.includes(r)} onChange={() => setRequests(toggle(requests, r))} />
          ))}
        </div>
      </FilterGroup>

      <FilterGroup title={`Стоимость сессии — до $${maxPrice}`}>
        <input
          type="range"
          min={20}
          max={70}
          step={5}
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          className="w-full accent-emerald-700"
        />
        <div className="mt-1 flex justify-between text-xs text-stone-400">
          <span>$20</span>
          <span>$70</span>
        </div>
      </FilterGroup>

      <FilterGroup title="Пол специалиста">
        <div className="flex flex-wrap gap-2">
          {GENDERS.map((g) => (
            <button
              key={g}
              onClick={() => setGender(g)}
              className={`rounded-full border px-4 py-1.5 text-sm transition-colors ${
                gender === g
                  ? "border-emerald-700 bg-emerald-700 text-white"
                  : "border-stone-200 text-stone-600 hover:border-emerald-300"
              }`}
            >
              {g}
            </button>
          ))}
        </div>
      </FilterGroup>

      <FilterGroup title="Метод терапии">
        <div className="flex flex-col">
          {METHODS.map((m) => (
            <Checkbox key={m} label={m} checked={methods.includes(m)} onChange={() => setMethods(toggle(methods, m))} />
          ))}
        </div>
      </FilterGroup>

      <FilterGroup title="Язык сессии">
        <div className="flex flex-col">
          {LANGUAGES.map((l) => (
            <Checkbox key={l} label={l} checked={languages.includes(l)} onChange={() => setLanguages(toggle(languages, l))} />
          ))}
        </div>
      </FilterGroup>

      <FilterGroup title="Формат">
        <div className="flex flex-col">
          {FORMATS.map((f) => (
            <Checkbox key={f} label={f} checked={formats.includes(f)} onChange={() => setFormats(toggle(formats, f))} />
          ))}
        </div>
      </FilterGroup>

      {activeCount > 0 && (
        <button
          onClick={() => {
            setRequests([]); setMethods([]); setLanguages([]); setFormats([]); setGender("Любой"); setMaxPrice(70);
          }}
          className="mt-4 text-sm font-semibold text-stone-500 underline underline-offset-2 hover:text-stone-700"
        >
          Сбросить все фильтры
        </button>
      )}
    </div>
  );

  return (
    <div className="font-body min-h-screen bg-stone-50 text-stone-800">
      <style>{FONT_IMPORT}</style>

      {/* TOP BAR */}
      <div className="border-b border-stone-200 bg-white">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-6 py-5 md:flex-row md:items-center md:justify-between">
          <div className="font-display text-xl text-emerald-800 shrink-0">тепло</div>
          <div className="flex flex-1 items-center gap-3 rounded-full border border-stone-200 px-5 py-3 md:max-w-lg">
            <Search size={18} className="shrink-0 text-stone-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск по имени специалиста"
              className="w-full bg-transparent text-sm text-stone-700 outline-none placeholder:text-stone-400"
            />
          </div>
          <button
            onClick={() => setFiltersOpen(true)}
            className="flex items-center justify-center gap-2 rounded-full border border-stone-200 px-5 py-3 text-sm font-medium text-stone-700 md:hidden"
          >
            <SlidersHorizontal size={16} />
            Фильтры {activeCount > 0 && `(${activeCount})`}
          </button>
        </div>
      </div>

      <div className="mx-auto flex max-w-6xl gap-10 px-6 py-10">
        {/* SIDEBAR - desktop */}
        <aside className="hidden w-64 shrink-0 md:block">{FiltersPanel}</aside>

        {/* MOBILE FILTERS DRAWER */}
        {filtersOpen && (
          <div className="fixed inset-0 z-50 flex md:hidden">
            <div className="absolute inset-0 bg-stone-900/40" onClick={() => setFiltersOpen(false)} />
            <div className="relative ml-auto flex h-full w-80 flex-col overflow-y-auto bg-white p-6">
              <div className="mb-4 flex items-center justify-between">
                <p className="font-display text-lg">Фильтры</p>
                <button onClick={() => setFiltersOpen(false)}>
                  <X size={20} />
                </button>
              </div>
              {FiltersPanel}
              <button
                onClick={() => setFiltersOpen(false)}
                className="mt-6 rounded-full bg-emerald-700 py-3 text-sm font-semibold text-white"
              >
                Показать {results.length} специалистов
              </button>
            </div>
          </div>
        )}

        {/* RESULTS */}
        <main className="flex-1">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="font-display text-2xl text-stone-900">Каталог специалистов</h1>
              <p className="mt-1 text-sm text-stone-500">Найдено {results.length} психологов</p>
            </div>
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none rounded-full border border-stone-200 bg-white py-2.5 pl-4 pr-9 text-sm text-stone-700 outline-none"
              >
                <option value="rating">По рейтингу</option>
                <option value="price_asc">Сначала дешевле</option>
                <option value="price_desc">Сначала дороже</option>
                <option value="experience">По опыту</option>
              </select>
              <ChevronDown size={16} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-stone-400" />
            </div>
          </div>

          {results.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-stone-300 py-20 text-center">
              <p className="font-display text-xl text-stone-700">Никого не нашлось</p>
              <p className="mt-2 text-sm text-stone-500">Попробуйте снизить бюджет или снять часть фильтров</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              {results.map((s) => (
                <div key={s.id} className="flex flex-col overflow-hidden rounded-3xl border border-stone-200 bg-white">
                  <div className="relative flex h-36 items-center justify-center bg-gradient-to-br from-sky-100 to-emerald-50">
                    <button className="flex h-12 w-12 items-center justify-center rounded-full bg-white/90 text-emerald-800 shadow-md">
                      <PlayCircle size={24} />
                    </button>
                    <span className="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-white/90 px-3 py-1 text-xs font-medium text-emerald-800">
                      <ShieldCheck size={12} /> Верифицирован
                    </span>
                  </div>

                  <div className="flex flex-1 flex-col p-5">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-display text-lg text-stone-900">{s.name}</p>
                        <p className="text-sm text-stone-500">{s.methods.join(", ")} · {s.experience} лет опыта</p>
                      </div>
                      <div className="flex shrink-0 items-center gap-1 text-sm text-amber-600">
                        <Star size={14} className="fill-amber-500 text-amber-500" />
                        {s.rating}
                        <span className="text-stone-400">({s.reviews})</span>
                      </div>
                    </div>

                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {s.requests.map((r) => (
                        <span key={r} className="rounded-full bg-stone-100 px-3 py-1 text-xs text-stone-600">
                          {r}
                        </span>
                      ))}
                    </div>

                    <div className="mt-4 flex items-center gap-4 text-xs text-stone-500">
                      <span className="flex items-center gap-1">
                        <MapPin size={13} /> {s.city}
                      </span>
                      <span className="flex items-center gap-1">
                        <Video size={13} /> {s.formats.join(" / ")}
                      </span>
                    </div>

                    <div className="mt-5 flex items-center justify-between border-t border-stone-100 pt-4">
                      <span className="font-display text-lg text-stone-900">
                        ${s.price}
                      </span>
                      <button className="rounded-full bg-emerald-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-800">
                        Записаться
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
