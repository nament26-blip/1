import React, { useState } from "react";
import {
  Search, ShieldCheck, Heart, Users, Star, PlayCircle,
  ArrowRight, MessageCircle, CalendarCheck, Sparkles
} from "lucide-react";

const FONT_IMPORT = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,500&family=Manrope:wght@400;500;600;700;800&display=swap');
.font-display { font-family: 'Fraunces', serif; }
.font-body { font-family: 'Manrope', sans-serif; }
`;

const topics = [
  { title: "Тревога и стресс", desc: "Панические атаки, беспокойство, выгорание" },
  { title: "Отношения", desc: "Пары, расставания, доверие, близость" },
  { title: "Детско-родительские", desc: "Кризисы взросления, контакт с ребёнком" },
  { title: "Самооценка", desc: "Принятие себя, уверенность, границы" },
  { title: "Потеря и горе", desc: "Проживание утраты, поддержка в кризисе" },
  { title: "Работа и выгорание", desc: "Мотивация, баланс, смена деятельности" },
];

const featured = [
  {
    name: "Анна Соколова",
    role: "КПТ-терапевт, 8 лет практики",
    price: "от $40",
    rating: 4.9,
    reviews: 132,
    tag: "Тревога, отношения",
  },
  {
    name: "Марат Ким",
    role: "Психоаналитик, 12 лет практики",
    price: "от $55",
    rating: 4.8,
    reviews: 98,
    tag: "Самооценка, кризисы",
  },
  {
    name: "Елена Райс",
    role: "Семейный терапевт, 6 лет практики",
    price: "от $35",
    rating: 5.0,
    reviews: 61,
    tag: "Детско-родительские",
  },
];

function Pill({ children, variant = "primary", className = "", ...props }) {
  const base =
    "font-body inline-flex items-center justify-center gap-2 rounded-full px-7 py-4 text-base font-semibold transition-colors";
  const styles = {
    primary: "bg-emerald-700 text-stone-50 hover:bg-emerald-800",
    secondary: "bg-transparent text-emerald-800 border border-emerald-800/30 hover:bg-emerald-50",
    ghost: "bg-white/70 text-stone-700 hover:bg-white",
  };
  return (
    <button className={`${base} ${styles[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}

export default function LandingPage() {
  const [query, setQuery] = useState("");

  return (
    <div className="font-body min-h-screen bg-stone-50 text-stone-800">
      <style>{FONT_IMPORT}</style>

      {/* NAV */}
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <div className="font-display text-2xl text-emerald-800">тепло</div>
        <nav className="hidden items-center gap-8 text-sm font-medium text-stone-600 md:flex">
          <a href="#topics" className="hover:text-emerald-800">Запросы</a>
          <a href="#how" className="hover:text-emerald-800">Как это работает</a>
          <a href="#specialists" className="hover:text-emerald-800">Специалисты</a>
          <a href="#" className="hover:text-emerald-800">Для психологов</a>
        </nav>
        <Pill variant="secondary" className="!px-5 !py-2.5 text-sm">
          Войти
        </Pill>
      </header>

      {/* HERO */}
      <section className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-10 px-6 pb-20 pt-10 md:grid-cols-[1.1fr_0.9fr] md:pt-16">
        <div>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-emerald-50 px-4 py-2 text-sm text-emerald-800">
            <ShieldCheck size={16} />
            Все специалисты проходят проверку дипломов
          </div>
          <h1 className="font-display text-5xl leading-[1.08] text-stone-900 md:text-6xl">
            Найти своего психолога —
            <br />
            это тоже забота о себе
          </h1>
          <p className="mt-6 max-w-md text-lg text-stone-600">
            Расскажите, что вас беспокоит, а мы подберём специалиста
            по методу, стоимости и удобному времени. Без очередей
            и неловких звонков.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="flex flex-1 items-center gap-3 rounded-full border border-stone-200 bg-white px-5 py-4 shadow-sm">
              <Search size={20} className="text-stone-400 shrink-0" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Например: тревога перед экзаменом"
                className="w-full bg-transparent text-stone-700 outline-none placeholder:text-stone-400"
              />
            </div>
            <Pill variant="primary">
              Подобрать психолога
              <ArrowRight size={18} />
            </Pill>
          </div>

          <div className="mt-10 flex items-center gap-8 text-sm text-stone-500">
            <div className="flex items-center gap-2">
              <Users size={18} className="text-sky-600" />
              1 200+ клиентов
            </div>
            <div className="flex items-center gap-2">
              <Star size={18} className="text-amber-500" />
              4.9 средний рейтинг
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck size={18} className="text-emerald-600" />
              320 верифицированных специалистов
            </div>
          </div>
        </div>

        {/* organic hero visual, no stock-photo placeholder needed */}
        <div className="relative mx-auto aspect-square w-full max-w-sm">
          <div className="absolute inset-0 rounded-[45%_55%_60%_40%/50%_45%_55%_50%] bg-gradient-to-br from-emerald-100 via-sky-50 to-stone-100" />
          <div className="absolute inset-8 flex flex-col justify-between rounded-[40%_60%_55%_45%/55%_40%_60%_45%] bg-white/70 p-8 backdrop-blur-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald-700 text-white">
                <Heart size={18} />
              </div>
              <div>
                <p className="text-sm font-semibold text-stone-800">Сессия через 20 мин</p>
                <p className="text-xs text-stone-500">Онлайн, видеозвонок</p>
              </div>
            </div>
            <div className="rounded-2xl bg-white p-4 shadow-sm">
              <p className="text-xs text-stone-500">Ваш запрос</p>
              <p className="mt-1 text-sm font-medium text-stone-800">
                «Хочу разобраться с тревогой на работе»
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* TOPICS */}
      <section id="topics" className="mx-auto max-w-6xl px-6 py-16">
        <div className="mb-10 max-w-lg">
          <h2 className="font-display text-3xl text-stone-900">С чем чаще всего приходят</h2>
          <p className="mt-3 text-stone-600">
            Выберите тему — покажем специалистов, которые с ней работают.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {topics.map((t, i) => (
            <a
              key={t.title}
              href="#specialists"
              className={`group rounded-3xl border border-stone-200 p-6 transition-colors hover:border-emerald-300 hover:bg-emerald-50/50 ${
                i % 3 === 1 ? "sm:translate-y-3" : ""
              }`}
            >
              <p className="font-display text-xl text-stone-900">{t.title}</p>
              <p className="mt-2 text-sm text-stone-500">{t.desc}</p>
              <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-emerald-700 opacity-0 transition-opacity group-hover:opacity-100">
                Смотреть специалистов <ArrowRight size={14} />
              </span>
            </a>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS - real sequence, numbering justified */}
      <section id="how" className="bg-emerald-50/60 py-20">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="font-display text-3xl text-stone-900">Как это работает</h2>
          <div className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-3">
            {[
              { n: "1", title: "Расскажите о запросе", desc: "Короткая анкета или поиск по фильтрам — тема, бюджет, метод терапии, язык.", icon: Sparkles },
              { n: "2", title: "Выберите специалиста", desc: "Изучите профиль, видео-визитку, образование и отзывы других клиентов.", icon: Users },
              { n: "3", title: "Забронируйте сессию", desc: "Выберите удобный слот, формат — онлайн или очно — и оплатите в один клик.", icon: CalendarCheck },
            ].map((step) => (
              <div key={step.n} className="rounded-3xl bg-white p-8">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-stone-900 font-display text-lg text-white">
                  {step.n}
                </div>
                <p className="mt-5 font-display text-xl text-stone-900">{step.title}</p>
                <p className="mt-2 text-sm leading-relaxed text-stone-600">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED SPECIALISTS */}
      <section id="specialists" className="mx-auto max-w-6xl px-6 py-20">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-3xl text-stone-900">Специалисты недели</h2>
            <p className="mt-2 text-stone-600">Проверенные дипломы, реальные отзывы клиентов.</p>
          </div>
          <a href="#" className="flex items-center gap-1 text-sm font-semibold text-emerald-700">
            Весь каталог <ArrowRight size={14} />
          </a>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {featured.map((p) => (
            <div key={p.name} className="overflow-hidden rounded-3xl border border-stone-200 bg-white">
              <div className="relative flex h-44 items-center justify-center bg-gradient-to-br from-sky-100 to-emerald-50">
                <button className="flex h-14 w-14 items-center justify-center rounded-full bg-white/90 text-emerald-800 shadow-md transition-transform hover:scale-105">
                  <PlayCircle size={28} />
                </button>
                <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-xs font-medium text-stone-600">
                  видео-визитка
                </span>
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between">
                  <p className="font-display text-lg text-stone-900">{p.name}</p>
                  <div className="flex items-center gap-1 text-sm text-amber-600">
                    <Star size={14} className="fill-amber-500 text-amber-500" />
                    {p.rating}
                  </div>
                </div>
                <p className="mt-1 text-sm text-stone-500">{p.role}</p>
                <p className="mt-3 inline-block rounded-full bg-stone-100 px-3 py-1 text-xs text-stone-600">
                  {p.tag}
                </p>
                <div className="mt-5 flex items-center justify-between">
                  <span className="font-display text-lg text-stone-900">{p.price}</span>
                  <Pill variant="primary" className="!px-5 !py-2.5 text-sm">
                    Записаться
                  </Pill>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* TRUST / CTA */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="flex flex-col items-start justify-between gap-8 rounded-3xl bg-stone-900 p-10 text-stone-50 md:flex-row md:items-center md:p-14">
          <div className="max-w-md">
            <h2 className="font-display text-3xl">
              Первый шаг — самый честный разговор с собой
            </h2>
            <p className="mt-3 text-stone-300">
              Подбор занимает 2 минуты. Отменить или перенести сессию можно
              бесплатно за 24 часа до начала.
            </p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Pill variant="primary" className="bg-emerald-500 hover:bg-emerald-400">
              Подобрать психолога
            </Pill>
            <Pill variant="ghost" className="!bg-white/10 !text-white hover:!bg-white/20">
              <MessageCircle size={18} />
              Задать вопрос поддержке
            </Pill>
          </div>
        </div>
      </section>

      <footer className="border-t border-stone-200 py-10 text-center text-sm text-stone-500">
        © {new Date().getFullYear()} тепло — платформа поиска психологов
      </footer>
    </div>
  );
}
